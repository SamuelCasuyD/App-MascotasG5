package com.rincon.gt.efgarcid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfgarcidApplicationTests {

	@Test
	void contextLoads() {
	}

}
