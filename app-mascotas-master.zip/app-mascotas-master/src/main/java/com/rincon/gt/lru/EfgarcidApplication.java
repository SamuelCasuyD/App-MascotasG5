package com.rincon.gt.lru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfgarcidApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfgarcidApplication.class, args);
	}

}
